/*************************************************************************
	> File Name: status.h
	> Author: kwh
	> Mail: 
	> Created Time: 2019年10月11日 星期五 10时37分09秒
 ************************************************************************/

#ifndef _STATUS_H
#define _STATUS_H
#endif

#define TRUE 1
#define FALSE 0
#define OK 1
#define ERROR 0
#define INFEASIBLE -1
#define OVERFLOW -2

typedef int Status;
typedef int SElemType;
